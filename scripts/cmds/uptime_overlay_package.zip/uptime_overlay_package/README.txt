GOATBOT UPTIME IMAGE CMD

Files:
- uptime.js
- uptime.jpg (your blue magic-circle image)

IMPORTANT:
This version writes the current uptime onto the image itself before sending it.
It requires the npm package: jimp (tested with the Jimp 0.22.x API).

Install on the bot host, in the bot project folder:
  npm install jimp@0.22.12

Then place BOTH uptime.js and uptime.jpg in the same command folder (for example scripts/cmds), restart GoatBot, and run:
  /up
or
  /uptime

The uptime text is drawn in the middle of the image. Uptime is based on process.uptime(), so it resets when that Node.js bot process restarts.
